#include <cstdlib>
#include <cctype>
#include <climits>
#include <windows.h>
// 手动实现缺失的标准库函数(真是非常Amazing啊，我还要修编译器的bug)
namespace std {
    // 实现std::to_string
    // inline 内联函数
    inline string to_string(int value) {
        // C风格字符串
        char buffer[32];
        // int sprintf( char* buffer, const char* format, ... );
        // 作用：写结果到字符串buffer。
        sprintf(buffer, "%d", value);
        return string(buffer);
    }
    inline string to_string(long value) {
        char buffer[32];
        sprintf(buffer, "%ld", value);
        return string(buffer);
    }
    inline string to_string(long long value) {
        char buffer[32];
        // 老版本MinGW需要用%I64d代替%lld
        // static_cast<目标类型﻿>(表达式﻿)使用隐式和用户定义转换的组合来进行类型之间的转换，返回目标类型的值。
        // 我一直在用强制类型转换而不是static_cast<目标类型﻿>(表达式﻿)
        sprintf(buffer, "%I64d", static_cast<long long>(value));
        return string(buffer);
    }
    inline string to_string(unsigned int value) {
        char buffer[32];
        sprintf(buffer, "%u", value);
        return string(buffer);
    }
    inline string to_string(unsigned long value) {
        char buffer[32];
        sprintf(buffer, "%lu", value);
        return string(buffer);
    }
    inline string to_string(unsigned long long value) {
        char buffer[32];
        // 老版本MinGW需要用%I64u代替%llu
        sprintf(buffer, "%I64u", static_cast<unsigned long long>(value));
        return string(buffer);
    }
    inline string to_string(float value) {
        char buffer[32];
        sprintf(buffer, "%f", value);
        return string(buffer);
    }
    inline string to_string(double value) {
        char buffer[32];
        sprintf(buffer, "%f", value);
        return string(buffer);
    }
    // 实现std::stoi
    inline int stoi(const string& str, size_t* idx = 0, int base = 10) {
        char* endptr = 0;
        // 使用全局命名空间的strtol
        long result = ::strtol(str.c_str(), &endptr, base);
        if (idx) *idx = endptr - str.c_str();
        return static_cast<int>(result);
    }
    inline long stol(const string& str, size_t* idx = 0, int base = 10) {
        char* endptr = 0;
        long result = ::strtol(str.c_str(), &endptr, base);
        if (idx) *idx = endptr - str.c_str();
        return result;
    }
    // 完全手动实现stoll函数，不依赖任何64位转换函数
    inline long long stoll(const string& str, size_t* idx = 0, int base = 10) {
        // 确保base在合法范围内
        if (base < 2 or base > 36) {
            if (idx) *idx = 0;
            return 0;
        }
        const char* s = str.c_str();
        const char* start = s;
        long long result = 0;
        bool negative = false;
        // 跳过前导空格
        while (isspace(static_cast<unsigned char>(*s))) {
            ++s;
        }
        // 处理符号
        if (*s == '-' || *s == '+') {
            negative = (*s == '-');
            ++s;
        }
        // 处理数字
        while (true) {
            int digit;
            if (isdigit(static_cast<unsigned char>(*s))) {
                digit = *s - '0';
            } else if (isupper(static_cast<unsigned char>(*s))) {
                digit = *s - 'A' + 10;
            } else if (islower(static_cast<unsigned char>(*s))) {
                digit = *s - 'a' + 10;
            } else {
                // 遇到非数字字符时停止解析
                break;
            }
            if (digit >= base) {
                // 数字超出base范围时停止解析
                break;
            }
            // 防止溢出（使用<climits>头文件的LLONG_MAX和LLONG_MIN）
            if (!negative) {
                if (result > (LLONG_MAX - digit) / base) {
                    result = LLONG_MAX;
                    break;
                }
            } else {
                if (result < (LLONG_MIN + digit) / base) {
                    result = LLONG_MIN;
                    break;
                }
            }
            result = result * base + digit;
            ++s;
        }
        // 处理索引指针
        if (idx != nullptr) {
            *idx = s - start;
        }
        // 处理符号
        return negative ? -result : result;
    }
}
// 必须在包含json.hpp之前定义JSON_HAS_CPP_11=0
#define JSON_HAS_CPP_11 0
#include "nlohmann/json.hpp"
using nlohmann::json;
std::string UTF8ToGBK(const std::string& utf8Str) {
    if (utf8Str.empty()) {
        return "";
    }
    // 第一步：UTF-8转Unicode（UTF-16）
    int wLen = MultiByteToWideChar(CP_UTF8, 0, utf8Str.c_str(), -1, nullptr, 0);
    if (wLen == 0) {
        return "";
    }
    std::wstring wstr(wLen, 0);
    MultiByteToWideChar(CP_UTF8, 0, utf8Str.c_str(), -1, &wstr[0], wLen);
    // 第二步：Unicode转GBK
    int gbkLen = WideCharToMultiByte(936, 0, wstr.c_str(), -1, nullptr, 0, nullptr, nullptr);
    if (gbkLen == 0) {
        return "";
    }
    std::string gbkStr(gbkLen, 0);
    WideCharToMultiByte(936, 0, wstr.c_str(), -1, &gbkStr[0], gbkLen, nullptr, nullptr);
    // 去除末尾多余的'\0'
    if (!gbkStr.empty() && gbkStr.back() == '\0') {
        gbkStr.pop_back();
    }
    return gbkStr;
}
std::string GBKToUTF8(const std::string& gbkStr) {
    if (gbkStr.empty()) {
        return "";
    }
    // 第一步：GBK转Unicode（UTF-16）
    int wLen = MultiByteToWideChar(936, 0, gbkStr.c_str(), -1, nullptr, 0);
    if (wLen == 0) {
        return "";
    }    std::wstring wstr(wLen, 0);
    MultiByteToWideChar(936, 0, gbkStr.c_str(), -1, &wstr[0], wLen);
    // 第二步：Unicode转UTF-8
    int utf8Len = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, nullptr, 0, nullptr, nullptr);
    if (utf8Len == 0) {
        return "";
    }
    std::string utf8Str(utf8Len, 0);
    WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, &utf8Str[0], utf8Len, nullptr, nullptr);
    // 去除末尾多余的'\0'
    if (!utf8Str.empty() && utf8Str.back() == '\0') {
        utf8Str.pop_back();
    }
    return utf8Str;
}