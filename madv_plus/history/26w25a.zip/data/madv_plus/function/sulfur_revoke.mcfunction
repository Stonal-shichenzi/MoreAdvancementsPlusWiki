# 该函数仅用于测试
advancement revoke @s only madv_plus:adventure/sulfur_filled_with_wool
advancement revoke @s only madv_plus:adventure/sulfur_filled_with_stone_tool_materials
advancement revoke @s only madv_plus:adventure/sulfur_filled_with_colourful_blocks
advancement revoke @s only madv_plus:adventure/sulfur_filled_with_dirt_plus
advancement revoke @s only madv_plus:adventure/sulfur_filled_with_magma_block
advancement revoke @s only madv_plus:adventure/sulfur_filled_with_ores_plus
advancement revoke @s only madv_plus:adventure/sulfur_filled_with_soul_fire_base_blocks
advancement revoke @s only madv_plus:adventure/sulfur_filled_with_wood